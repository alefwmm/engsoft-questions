gdjs.mainCode = {};
gdjs.mainCode.userFunc0x1b6e20a8 = function(runtimeScene) {
console.log("TESTE 1")

};


gdjs.mainCode.GDplayerObjects1= [];
gdjs.mainCode.GDplayerObjects2= [];
gdjs.mainCode.GDplayerObjects3= [];
gdjs.mainCode.GDplayerObjects4= [];
gdjs.mainCode.GDwallObjects1= [];
gdjs.mainCode.GDwallObjects2= [];
gdjs.mainCode.GDwallObjects3= [];
gdjs.mainCode.GDwallObjects4= [];
gdjs.mainCode.GDwall2Objects1= [];
gdjs.mainCode.GDwall2Objects2= [];
gdjs.mainCode.GDwall2Objects3= [];
gdjs.mainCode.GDwall2Objects4= [];
gdjs.mainCode.GDgoalObjects1= [];
gdjs.mainCode.GDgoalObjects2= [];
gdjs.mainCode.GDgoalObjects3= [];
gdjs.mainCode.GDgoalObjects4= [];
gdjs.mainCode.GDbackgroundObjects1= [];
gdjs.mainCode.GDbackgroundObjects2= [];
gdjs.mainCode.GDbackgroundObjects3= [];
gdjs.mainCode.GDbackgroundObjects4= [];
gdjs.mainCode.GDpageObjects1= [];
gdjs.mainCode.GDpageObjects2= [];
gdjs.mainCode.GDpageObjects3= [];
gdjs.mainCode.GDpageObjects4= [];
gdjs.mainCode.GDdisplay1Objects1= [];
gdjs.mainCode.GDdisplay1Objects2= [];
gdjs.mainCode.GDdisplay1Objects3= [];
gdjs.mainCode.GDdisplay1Objects4= [];
gdjs.mainCode.GDdisplay2Objects1= [];
gdjs.mainCode.GDdisplay2Objects2= [];
gdjs.mainCode.GDdisplay2Objects3= [];
gdjs.mainCode.GDdisplay2Objects4= [];
gdjs.mainCode.GDparchmentObjects1= [];
gdjs.mainCode.GDparchmentObjects2= [];
gdjs.mainCode.GDparchmentObjects3= [];
gdjs.mainCode.GDparchmentObjects4= [];
gdjs.mainCode.GDNewObjectObjects1= [];
gdjs.mainCode.GDNewObjectObjects2= [];
gdjs.mainCode.GDNewObjectObjects3= [];
gdjs.mainCode.GDNewObjectObjects4= [];
gdjs.mainCode.GDNewObject2Objects1= [];
gdjs.mainCode.GDNewObject2Objects2= [];
gdjs.mainCode.GDNewObject2Objects3= [];
gdjs.mainCode.GDNewObject2Objects4= [];
gdjs.mainCode.GDAquele_95que_95te_95persegueObjects1= [];
gdjs.mainCode.GDAquele_95que_95te_95persegueObjects2= [];
gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3= [];
gdjs.mainCode.GDAquele_95que_95te_95persegueObjects4= [];
gdjs.mainCode.GDTestePerguntaObjects1= [];
gdjs.mainCode.GDTestePerguntaObjects2= [];
gdjs.mainCode.GDTestePerguntaObjects3= [];
gdjs.mainCode.GDTestePerguntaObjects4= [];

gdjs.mainCode.conditionTrue_0 = {val:false};
gdjs.mainCode.condition0IsTrue_0 = {val:false};
gdjs.mainCode.condition1IsTrue_0 = {val:false};

gdjs.mainCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.mainCode.GDplayerObjects1.length = 0;
gdjs.mainCode.GDplayerObjects2.length = 0;
gdjs.mainCode.GDplayerObjects3.length = 0;
gdjs.mainCode.GDplayerObjects4.length = 0;
gdjs.mainCode.GDwallObjects1.length = 0;
gdjs.mainCode.GDwallObjects2.length = 0;
gdjs.mainCode.GDwallObjects3.length = 0;
gdjs.mainCode.GDwallObjects4.length = 0;
gdjs.mainCode.GDwall2Objects1.length = 0;
gdjs.mainCode.GDwall2Objects2.length = 0;
gdjs.mainCode.GDwall2Objects3.length = 0;
gdjs.mainCode.GDwall2Objects4.length = 0;
gdjs.mainCode.GDgoalObjects1.length = 0;
gdjs.mainCode.GDgoalObjects2.length = 0;
gdjs.mainCode.GDgoalObjects3.length = 0;
gdjs.mainCode.GDgoalObjects4.length = 0;
gdjs.mainCode.GDbackgroundObjects1.length = 0;
gdjs.mainCode.GDbackgroundObjects2.length = 0;
gdjs.mainCode.GDbackgroundObjects3.length = 0;
gdjs.mainCode.GDbackgroundObjects4.length = 0;
gdjs.mainCode.GDpageObjects1.length = 0;
gdjs.mainCode.GDpageObjects2.length = 0;
gdjs.mainCode.GDpageObjects3.length = 0;
gdjs.mainCode.GDpageObjects4.length = 0;
gdjs.mainCode.GDdisplay1Objects1.length = 0;
gdjs.mainCode.GDdisplay1Objects2.length = 0;
gdjs.mainCode.GDdisplay1Objects3.length = 0;
gdjs.mainCode.GDdisplay1Objects4.length = 0;
gdjs.mainCode.GDdisplay2Objects1.length = 0;
gdjs.mainCode.GDdisplay2Objects2.length = 0;
gdjs.mainCode.GDdisplay2Objects3.length = 0;
gdjs.mainCode.GDdisplay2Objects4.length = 0;
gdjs.mainCode.GDparchmentObjects1.length = 0;
gdjs.mainCode.GDparchmentObjects2.length = 0;
gdjs.mainCode.GDparchmentObjects3.length = 0;
gdjs.mainCode.GDparchmentObjects4.length = 0;
gdjs.mainCode.GDNewObjectObjects1.length = 0;
gdjs.mainCode.GDNewObjectObjects2.length = 0;
gdjs.mainCode.GDNewObjectObjects3.length = 0;
gdjs.mainCode.GDNewObjectObjects4.length = 0;
gdjs.mainCode.GDNewObject2Objects1.length = 0;
gdjs.mainCode.GDNewObject2Objects2.length = 0;
gdjs.mainCode.GDNewObject2Objects3.length = 0;
gdjs.mainCode.GDNewObject2Objects4.length = 0;
gdjs.mainCode.GDAquele_95que_95te_95persegueObjects1.length = 0;
gdjs.mainCode.GDAquele_95que_95te_95persegueObjects2.length = 0;
gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3.length = 0;
gdjs.mainCode.GDAquele_95que_95te_95persegueObjects4.length = 0;
gdjs.mainCode.GDTestePerguntaObjects1.length = 0;
gdjs.mainCode.GDTestePerguntaObjects2.length = 0;
gdjs.mainCode.GDTestePerguntaObjects3.length = 0;
gdjs.mainCode.GDTestePerguntaObjects4.length = 0;


{

gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 0;
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.centerCameraWithinLimits(runtimeScene, (gdjs.mainCode.GDplayerObjects1.length !== 0 ? gdjs.mainCode.GDplayerObjects1[0] : null), 0, -32, 800, 705, false, "", 0);
}{gdjs.evtTools.window.setCanvasSize(runtimeScene, 200, 150, true);
}}

}


{

gdjs.mainCode.GDgoalObjects1.createFrom(runtimeScene.getObjects("goal"));
gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("player", gdjs.mainCode.GDplayerObjects1).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("goal", gdjs.mainCode.GDgoalObjects1).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}{gdjs.evtTools.window.setCanvasSize(runtimeScene, 800, 600, true);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.mainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDplayerObjects1[i].setAnimation(4);
}
}}

}


{

gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.mainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDplayerObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.mainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDplayerObjects1[i].setAnimation(2);
}
}}

}


{

gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.mainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDplayerObjects1[i].setAnimation(3);
}
}}

}


{

gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Up");
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.mainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDplayerObjects1[i].setAnimation(0);
}
}}

}


{

gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Right");
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.mainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDplayerObjects1[i].setAnimation(5);
}
}}

}


{

gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Down");
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.mainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDplayerObjects1[i].setAnimation(6);
}
}}

}


{


gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.random(3));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(0);
}}

}


{

gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Left");
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.mainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDplayerObjects1[i].setAnimation(7);
}
}}

}


{


gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 0;
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(6).setString("");
}}

}


{


gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(6).setString("");
}}

}


{


gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 2;
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(6).setString("");
}}

}


{


gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 3;
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(6).setString("");
}}

}


{


gdjs.mainCode.userFunc0x1b6e20a8(runtimeScene);

}


{

gdjs.mainCode.GDpageObjects1.createFrom(runtimeScene.getObjects("page"));
gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("player", gdjs.mainCode.GDplayerObjects1).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("page", gdjs.mainCode.GDpageObjects1).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{runtimeScene.getGame().getVariables().get("gotHint").setNumber(1);
}{for(var i = 0, len = gdjs.mainCode.GDpageObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDpageObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("gotHint")) == 1;
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "hintScene");
}}

}


{

gdjs.mainCode.GDNewObject2Objects1.createFrom(runtimeScene.getObjects("NewObject2"));
gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("player", gdjs.mainCode.GDplayerObjects1).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("NewObject2", gdjs.mainCode.GDNewObject2Objects1).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gameover", false);
}{gdjs.evtTools.window.setCanvasSize(runtimeScene, 800, 600, true);
}}

}


{

gdjs.mainCode.GDAquele_95que_95te_95persegueObjects1.createFrom(runtimeScene.getObjects("Aquele_que_te_persegue"));
gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("player", gdjs.mainCode.GDplayerObjects1).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("Aquele_que_te_persegue", gdjs.mainCode.GDAquele_95que_95te_95persegueObjects1).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.window.setCanvasSize(runtimeScene, 800, 600, true);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gameover", false);
}}

}


{

gdjs.mainCode.GDTestePerguntaObjects1.createFrom(runtimeScene.getObjects("TestePergunta"));
gdjs.mainCode.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("player", gdjs.mainCode.GDplayerObjects1).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("TestePergunta", gdjs.mainCode.GDTestePerguntaObjects1).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.mainCode.GDTestePerguntaObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDTestePerguntaObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.window.setCanvasSize(runtimeScene, 800, 600, true);
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "questionScene");
}}

}


{


gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs.mainCode.condition0IsTrue_0.val) {

{ //Subevents

{


gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 0;
}if (gdjs.mainCode.condition0IsTrue_0.val) {

{ //Subevents

{

gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3.createFrom(runtimeScene.getObjects("Aquele_que_te_persegue"));
gdjs.mainCode.GDplayerObjects3.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(context.clearEventsObjectsMap().addObjectsToEventsMap("Aquele_que_te_persegue", gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("player", gdjs.mainCode.GDplayerObjects3).getEventsObjectsMap(), 400, false);
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "AI");
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "AI");
}}

}


{

gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3.createFrom(runtimeScene.getObjects("Aquele_que_te_persegue"));
gdjs.mainCode.GDplayerObjects3.createFrom(runtimeScene.getObjects("player"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(context.clearEventsObjectsMap().addObjectsToEventsMap("Aquele_que_te_persegue", gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("player", gdjs.mainCode.GDplayerObjects3).getEventsObjectsMap(), 400, true);
}if (gdjs.mainCode.condition0IsTrue_0.val) {

{ //Subevents

{

gdjs.mainCode.GDAquele_95que_95te_95persegueObjects4.createFrom(gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3);
gdjs.mainCode.GDwall2Objects4.createFrom(runtimeScene.getObjects("wall2"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("Aquele_que_te_persegue", gdjs.mainCode.GDAquele_95que_95te_95persegueObjects4).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("wall2", gdjs.mainCode.GDwall2Objects4).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.random(3));
}{for(var i = 0, len = gdjs.mainCode.GDAquele_95que_95te_95persegueObjects4.length ;i < len;++i) {
    gdjs.mainCode.GDAquele_95que_95te_95persegueObjects4[i].addPolarForce(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))*90, 400, 0);
}
}}

}

} //End of subevents
}

}

} //End of subevents
}

}


{


gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 1;
}if (gdjs.mainCode.condition0IsTrue_0.val) {

{ //Subevents

{

gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3.createFrom(runtimeScene.getObjects("Aquele_que_te_persegue"));
gdjs.mainCode.GDwall2Objects3.createFrom(runtimeScene.getObjects("wall2"));

gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("Aquele_que_te_persegue", gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("wall2", gdjs.mainCode.GDwall2Objects3).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.random(3));
}{for(var i = 0, len = gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3.length ;i < len;++i) {
    gdjs.mainCode.GDAquele_95que_95te_95persegueObjects3[i].addPolarForce(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))*90, 400, 0);
}
}}

}

} //End of subevents
}

}

} //End of subevents
}

}


{


gdjs.mainCode.condition0IsTrue_0.val = false;
{
gdjs.mainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 10, "AI");
}if (gdjs.mainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(0);
}}

}

return;
}
gdjs['mainCode']= gdjs.mainCode;
