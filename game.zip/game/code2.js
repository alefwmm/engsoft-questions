gdjs.questionSceneCode = {};


gdjs.questionSceneCode.GDquestionObjects1= [];
gdjs.questionSceneCode.GDparchmentObjects1= [];
gdjs.questionSceneCode.GDbackgroundObjects1= [];
gdjs.questionSceneCode.GDreturnTextObjects1= [];
gdjs.questionSceneCode.GDaObjects1= [];
gdjs.questionSceneCode.GDbObjects1= [];
gdjs.questionSceneCode.GDcObjects1= [];

gdjs.questionSceneCode.conditionTrue_0 = {val:false};
gdjs.questionSceneCode.condition0IsTrue_0 = {val:false};
gdjs.questionSceneCode.condition1IsTrue_0 = {val:false};
gdjs.questionSceneCode.condition2IsTrue_0 = {val:false};

gdjs.questionSceneCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.questionSceneCode.GDquestionObjects1.length = 0;
gdjs.questionSceneCode.GDparchmentObjects1.length = 0;
gdjs.questionSceneCode.GDbackgroundObjects1.length = 0;
gdjs.questionSceneCode.GDreturnTextObjects1.length = 0;
gdjs.questionSceneCode.GDaObjects1.length = 0;
gdjs.questionSceneCode.GDbObjects1.length = 0;
gdjs.questionSceneCode.GDcObjects1.length = 0;


{

gdjs.questionSceneCode.GDaObjects1.createFrom(runtimeScene.getObjects("a"));
gdjs.questionSceneCode.GDbObjects1.createFrom(runtimeScene.getObjects("b"));
gdjs.questionSceneCode.GDcObjects1.createFrom(runtimeScene.getObjects("c"));
gdjs.questionSceneCode.GDquestionObjects1.createFrom(runtimeScene.getObjects("question"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.questionSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.network.sendHttpRequest("http://104.197.217.39", "/question", "", "GET", "", runtimeScene.getVariables().getFromIndex(1));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)), runtimeScene.getVariables().getFromIndex(2));
}{for(var i = 0, len = gdjs.questionSceneCode.GDquestionObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDquestionObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("text")));
}
}{for(var i = 0, len = gdjs.questionSceneCode.GDaObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDaObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("correct")));
}
}{for(var i = 0, len = gdjs.questionSceneCode.GDbObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDbObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("incorrect").getChild("0")));
}
}{for(var i = 0, len = gdjs.questionSceneCode.GDcObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDcObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2).getChild("incorrect").getChild("1")));
}
}{gdjs.evtTools.window.setCanvasSize(runtimeScene, 800, 600, true);
}{for(var i = 0, len = gdjs.questionSceneCode.GDaObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDaObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.questionSceneCode.GDbObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDbObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.questionSceneCode.GDcObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDcObjects1[i].setOpacity(0);
}
}}

}


{

gdjs.questionSceneCode.GDaObjects1.createFrom(runtimeScene.getObjects("a"));
gdjs.questionSceneCode.GDbObjects1.createFrom(runtimeScene.getObjects("b"));
gdjs.questionSceneCode.GDcObjects1.createFrom(runtimeScene.getObjects("c"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
gdjs.questionSceneCode.condition1IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "showText");
}if ( gdjs.questionSceneCode.condition0IsTrue_0.val ) {
{
gdjs.questionSceneCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.1, "fadeIn");
}}
if (gdjs.questionSceneCode.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.questionSceneCode.GDaObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDaObjects1[i].setOpacity(gdjs.questionSceneCode.GDaObjects1[i].getOpacity() + (10));
}
}{for(var i = 0, len = gdjs.questionSceneCode.GDbObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDbObjects1[i].setOpacity(gdjs.questionSceneCode.GDbObjects1[i].getOpacity() + (10));
}
}{for(var i = 0, len = gdjs.questionSceneCode.GDcObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDcObjects1[i].setOpacity(gdjs.questionSceneCode.GDcObjects1[i].getOpacity() + (10));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "fadeIn");
}}

}


{

gdjs.questionSceneCode.GDaObjects1.createFrom(runtimeScene.getObjects("a"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("a", gdjs.questionSceneCode.GDaObjects1).getEventsObjectsMap(), runtimeScene, true, false);
}if (gdjs.questionSceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.questionSceneCode.GDaObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDaObjects1[i].setColor("255;0;0");
}
}}

}


{

gdjs.questionSceneCode.GDaObjects1.createFrom(runtimeScene.getObjects("a"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
gdjs.questionSceneCode.condition1IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.questionSceneCode.condition0IsTrue_0.val ) {
{
gdjs.questionSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("a", gdjs.questionSceneCode.GDaObjects1).getEventsObjectsMap(), runtimeScene, true, false);
}}
if (gdjs.questionSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}{gdjs.evtTools.window.setCanvasSize(runtimeScene, 200, 150, false);
}{runtimeScene.getGame().getVariables().get("scorePoints").add(10);
}}

}


{

gdjs.questionSceneCode.GDaObjects1.createFrom(runtimeScene.getObjects("a"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("a", gdjs.questionSceneCode.GDaObjects1).getEventsObjectsMap(), runtimeScene, true, true);
}if (gdjs.questionSceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.questionSceneCode.GDaObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDaObjects1[i].setColor("0;0;0");
}
}}

}


{

gdjs.questionSceneCode.GDbObjects1.createFrom(runtimeScene.getObjects("b"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("b", gdjs.questionSceneCode.GDbObjects1).getEventsObjectsMap(), runtimeScene, true, false);
}if (gdjs.questionSceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.questionSceneCode.GDbObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDbObjects1[i].setColor("255;0;0");
}
}}

}


{

gdjs.questionSceneCode.GDbObjects1.createFrom(runtimeScene.getObjects("b"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
gdjs.questionSceneCode.condition1IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.questionSceneCode.condition0IsTrue_0.val ) {
{
gdjs.questionSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("b", gdjs.questionSceneCode.GDbObjects1).getEventsObjectsMap(), runtimeScene, true, false);
}}
if (gdjs.questionSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.window.setCanvasSize(runtimeScene, 800, 600, true);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gameover", false);
}}

}


{

gdjs.questionSceneCode.GDbObjects1.createFrom(runtimeScene.getObjects("b"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("b", gdjs.questionSceneCode.GDbObjects1).getEventsObjectsMap(), runtimeScene, true, true);
}if (gdjs.questionSceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.questionSceneCode.GDbObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDbObjects1[i].setColor("0;0;0");
}
}}

}


{

gdjs.questionSceneCode.GDcObjects1.createFrom(runtimeScene.getObjects("c"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("c", gdjs.questionSceneCode.GDcObjects1).getEventsObjectsMap(), runtimeScene, true, false);
}if (gdjs.questionSceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.questionSceneCode.GDcObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDcObjects1[i].setColor("255;0;0");
}
}}

}


{

gdjs.questionSceneCode.GDcObjects1.createFrom(runtimeScene.getObjects("c"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
gdjs.questionSceneCode.condition1IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.questionSceneCode.condition0IsTrue_0.val ) {
{
gdjs.questionSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("c", gdjs.questionSceneCode.GDcObjects1).getEventsObjectsMap(), runtimeScene, true, false);
}}
if (gdjs.questionSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.window.setCanvasSize(runtimeScene, 800, 600, true);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gameover", false);
}}

}


{

gdjs.questionSceneCode.GDcObjects1.createFrom(runtimeScene.getObjects("c"));

gdjs.questionSceneCode.condition0IsTrue_0.val = false;
{
gdjs.questionSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("c", gdjs.questionSceneCode.GDcObjects1).getEventsObjectsMap(), runtimeScene, true, true);
}if (gdjs.questionSceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.questionSceneCode.GDcObjects1.length ;i < len;++i) {
    gdjs.questionSceneCode.GDcObjects1[i].setColor("0;0;0");
}
}}

}

return;
}
gdjs['questionSceneCode']= gdjs.questionSceneCode;
