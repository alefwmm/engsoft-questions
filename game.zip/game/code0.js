gdjs.menuCode = {};


gdjs.menuCode.GDmenuBkgObjects1= [];
gdjs.menuCode.GDtitleObjects1= [];
gdjs.menuCode.GDplayObjects1= [];
gdjs.menuCode.GDoptionsObjects1= [];
gdjs.menuCode.GDcreditsObjects1= [];

gdjs.menuCode.conditionTrue_0 = {val:false};
gdjs.menuCode.condition0IsTrue_0 = {val:false};
gdjs.menuCode.condition1IsTrue_0 = {val:false};
gdjs.menuCode.condition2IsTrue_0 = {val:false};

gdjs.menuCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.menuCode.GDmenuBkgObjects1.length = 0;
gdjs.menuCode.GDtitleObjects1.length = 0;
gdjs.menuCode.GDplayObjects1.length = 0;
gdjs.menuCode.GDoptionsObjects1.length = 0;
gdjs.menuCode.GDcreditsObjects1.length = 0;


{


gdjs.menuCode.condition0IsTrue_0.val = false;
{
gdjs.menuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.network.sendHttpRequest("http://104.197.217.39", "/init/8", "", "GET", "", gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.menuCode.condition0IsTrue_0.val = false;
gdjs.menuCode.condition1IsTrue_0.val = false;
{
gdjs.menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if ( gdjs.menuCode.condition0IsTrue_0.val ) {
{
gdjs.menuCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 0;
}}
if (gdjs.menuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "main", false);
}{gdjs.evtTools.window.setCanvasSize(runtimeScene, 200, 150, true);
}}

}

return;
}
gdjs['menuCode']= gdjs.menuCode;
