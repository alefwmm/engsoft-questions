gdjs.gameoverCode = {};


gdjs.gameoverCode.GDlooserObjects1= [];
gdjs.gameoverCode.GDNewObjectObjects1= [];
gdjs.gameoverCode.GDpontuacaoObjects1= [];

gdjs.gameoverCode.conditionTrue_0 = {val:false};
gdjs.gameoverCode.condition0IsTrue_0 = {val:false};
gdjs.gameoverCode.condition1IsTrue_0 = {val:false};

gdjs.gameoverCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.gameoverCode.GDlooserObjects1.length = 0;
gdjs.gameoverCode.GDNewObjectObjects1.length = 0;
gdjs.gameoverCode.GDpontuacaoObjects1.length = 0;


{

gdjs.gameoverCode.GDpontuacaoObjects1.createFrom(runtimeScene.getObjects("pontuacao"));

gdjs.gameoverCode.condition0IsTrue_0.val = false;
{
gdjs.gameoverCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.gameoverCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.gameoverCode.GDpontuacaoObjects1.length ;i < len;++i) {
    gdjs.gameoverCode.GDpontuacaoObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("scorePoints")));
}
}}

}


{


gdjs.gameoverCode.condition0IsTrue_0.val = false;
{
gdjs.gameoverCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if (gdjs.gameoverCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}}

}

return;
}
gdjs['gameoverCode']= gdjs.gameoverCode;
