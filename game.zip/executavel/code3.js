gdjs.hintSceneCode = {};


gdjs.hintSceneCode.GDparchmentObjects1= [];
gdjs.hintSceneCode.GDbackgroundObjects1= [];
gdjs.hintSceneCode.GDhint_95displayObjects1= [];
gdjs.hintSceneCode.GDreturnTextObjects1= [];

gdjs.hintSceneCode.conditionTrue_0 = {val:false};
gdjs.hintSceneCode.condition0IsTrue_0 = {val:false};
gdjs.hintSceneCode.condition1IsTrue_0 = {val:false};
gdjs.hintSceneCode.condition2IsTrue_0 = {val:false};

gdjs.hintSceneCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.hintSceneCode.GDparchmentObjects1.length = 0;
gdjs.hintSceneCode.GDbackgroundObjects1.length = 0;
gdjs.hintSceneCode.GDhint_95displayObjects1.length = 0;
gdjs.hintSceneCode.GDreturnTextObjects1.length = 0;


{

gdjs.hintSceneCode.GDhint_95displayObjects1.createFrom(runtimeScene.getObjects("hint_display"));

gdjs.hintSceneCode.condition0IsTrue_0.val = false;
{
gdjs.hintSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if (gdjs.hintSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}{gdjs.evtTools.window.setCanvasSize(runtimeScene, 200, 150, false);
}{for(var i = 0, len = gdjs.hintSceneCode.GDhint_95displayObjects1.length ;i < len;++i) {
    gdjs.hintSceneCode.GDhint_95displayObjects1[i].setOpacity(0);
}
}}

}


{

gdjs.hintSceneCode.GDhint_95displayObjects1.createFrom(runtimeScene.getObjects("hint_display"));
gdjs.hintSceneCode.GDreturnTextObjects1.createFrom(runtimeScene.getObjects("returnText"));

gdjs.hintSceneCode.condition0IsTrue_0.val = false;
{
gdjs.hintSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.hintSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.network.sendHttpRequest("http://104.197.217.39", "/hint", "", "GET", "", runtimeScene.getVariables().getFromIndex(1));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)), runtimeScene.getVariables().getFromIndex(2));
}{runtimeScene.getGame().getVariables().get("gotHint").setNumber(0);
}{gdjs.evtTools.window.setCanvasSize(runtimeScene, 800, 600, true);
}{for(var i = 0, len = gdjs.hintSceneCode.GDhint_95displayObjects1.length ;i < len;++i) {
    gdjs.hintSceneCode.GDhint_95displayObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.hintSceneCode.GDreturnTextObjects1.length ;i < len;++i) {
    gdjs.hintSceneCode.GDreturnTextObjects1[i].setOpacity(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(9).add(5);
}}

}


{

gdjs.hintSceneCode.GDhint_95displayObjects1.createFrom(runtimeScene.getObjects("hint_display"));
gdjs.hintSceneCode.GDreturnTextObjects1.createFrom(runtimeScene.getObjects("returnText"));

gdjs.hintSceneCode.condition0IsTrue_0.val = false;
gdjs.hintSceneCode.condition1IsTrue_0.val = false;
{
gdjs.hintSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "showText");
}if ( gdjs.hintSceneCode.condition0IsTrue_0.val ) {
{
gdjs.hintSceneCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.1, "fadeIn");
}}
if (gdjs.hintSceneCode.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.hintSceneCode.GDreturnTextObjects1.length ;i < len;++i) {
    gdjs.hintSceneCode.GDreturnTextObjects1[i].setOpacity(gdjs.hintSceneCode.GDreturnTextObjects1[i].getOpacity() + (10));
}
}{for(var i = 0, len = gdjs.hintSceneCode.GDhint_95displayObjects1.length ;i < len;++i) {
    gdjs.hintSceneCode.GDhint_95displayObjects1[i].setOpacity(gdjs.hintSceneCode.GDhint_95displayObjects1[i].getOpacity() + (10));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "fadeIn");
}}

}

return;
}
gdjs['hintSceneCode']= gdjs.hintSceneCode;
